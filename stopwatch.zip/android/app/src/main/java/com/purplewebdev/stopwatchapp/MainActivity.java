package com.purplewebdev.stopwatchapp;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
