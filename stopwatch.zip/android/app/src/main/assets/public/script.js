//variable initialisation
let timeElapsed = 0; //will store the time elapsed
let timerInterval = null; //stores setInterval
let laps = [] //initialise an empty array to store lap times

function updateTimer(){      //this function serves to show the time elapsed on the stopWatch interface
  const display = document.querySelector(".display");
  const minutes = Math.floor(timeElapsed / 60000);
  const seconds = Math.floor((timeElapsed % 60000) / 1000);
  const milliseconds = Math.floor((timeElapsed % 1000) / 10);
  
  display.textContent = `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}:${String(milliseconds).padStart(2, "0")}`
}

//initialising buttons
const start = document.querySelector(".start");
const stop = document.querySelector(".stop");
const reset = document.querySelector(".reset");
const lap = document.querySelector(".lap");

//button functionality
//START
start.addEventListener('click', () =>
  {if(timerInterval)return; //does nothing if timer is already running
  timerInterval = setInterval(() =>
    {timeElapsed += 10
      updateTimer()
    }, 10)}
)

//STOP
stop.addEventListener('click', () => {
  clearInterval(timerInterval)
  timerInterval = null
})

//RESET
reset.addEventListener('click', () => {
  timeElapsed = 0;
  updateTimer()
  laps =[]
  const lapList = document.querySelector(".lapList")
  lapList.innerHTML = " "
})

//LAP 
lap.addEventListener('click', () => {
  if(!timerInterval)return; //only lap when running
  laps.push(timeElapsed)
  const lapList = document.querySelector(".lapList")
  lapList.innerHTML += `<li>Lap ${laps.length}: ${document.querySelector(".display").textContent}</li>`
})

updateTimer()
