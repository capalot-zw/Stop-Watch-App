└── □ www/-
    ├── file_structure.fs
    ├── index.html
    ├── script.js
    └── styles.css
